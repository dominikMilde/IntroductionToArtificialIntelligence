def readHeuristics(path):
    keyValue = {}
    f = open(path)
    while True:
        a = f.readline()
        if a == "":
            break
        else:
            splitted = a.split(':')
            keyValue[splitted[0]] = float(splitted[1])
    return keyValue
