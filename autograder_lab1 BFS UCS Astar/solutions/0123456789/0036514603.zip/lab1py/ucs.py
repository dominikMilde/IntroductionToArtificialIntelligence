from queue import PriorityQueue


def ucs(startNode, endNodes, transitions):
    visited = set()
    queue = PriorityQueue()

    queue.put((0, startNode, (startNode,)))
    while queue:
        #print("aaa")
        #print(queue.queue)
        f, current_node, path = queue.get()
        visited.add(current_node)
        #print(f, current_node, path)
        if current_node in endNodes:
            return True, len(visited), len(path), float(f), path,
        for neighbour in transitions[current_node]:
            if neighbour[0] not in visited:
                queue.put((f+neighbour[1], neighbour[0], path + (neighbour[0],)))
    return False,