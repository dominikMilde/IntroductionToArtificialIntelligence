def bfs(startNode, endNodes, transitions):
    visited = set()
    queue = []
    queue.append([startNode])
    visited.add(startNode)
    while queue:
        #print(queue)
        path = queue.pop(0)
        n = path[-1]
        #print(n)
        visited.add(n)

        if n in endNodes:
            cost = 0
            for i in range(0, len(path)-1):
                for j in transitions[path[i]]:
                    if j[0] == path[i+1]:
                        cost += j[1]

            return True, len(visited), len(path), float(cost), path,

        listSorted = []
        for neighbour in transitions[n]:
            listSorted.append(neighbour[0])
        listSorted.sort()

        for neighbour in listSorted:
            if neighbour not in visited:
                newPath = list(path)
                newPath.append(neighbour)
                queue.append(newPath)
    return False,
