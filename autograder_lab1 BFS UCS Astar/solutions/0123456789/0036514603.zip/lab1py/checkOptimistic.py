from ucs import ucs


def checkOptimistic(heuristics, startNode, endNodes, transitions):
    passed = True
    for h in heuristics:
        real = ucs(h, endNodes, transitions)
        if heuristics[h] <= real[3]:
            print("[CONDITION]: [OK] h(" + h+") <= h*:", heuristics[h], "<=", round(real[3], 1))
        else:
            print("[CONDITION]: [ERR] h(" + h+") <= h*:", heuristics[h], "<=", round(real[3], 1))
            passed = False

    if passed:
        print("[CONCLUSION]: Heuristic is optimistic.")
    else:
        print("[CONCLUSION]: Heuristic is not optimistic.")
    return
