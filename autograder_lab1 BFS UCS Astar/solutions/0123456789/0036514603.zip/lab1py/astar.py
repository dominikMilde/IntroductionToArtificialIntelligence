from queue import PriorityQueue


def astar(startNode, endNodes, transitions, heuristics):
    open = PriorityQueue()
    open.put((0, startNode,))
    parents = dict()
    cost = dict()
    parents[startNode] = None
    cost[startNode] = 0

    while not open.empty():
        #print(frontier.queue)
        current = open.get()
        #print(current)

        if current[1] in endNodes:
            path = [current[1]]
            while path[-1] != startNode:
                path.append(parents[path[-1]])
            path.reverse()
            #print(path)
            #print(current[0])
            return True, len(parents), len(path), float(current[0]), path,

        for neighbour in transitions[current[1]]:
            newCost = cost[current[1]] + neighbour[1]
            if neighbour[0] not in cost or newCost < cost[neighbour[0]]:
                cost[neighbour[0]] = newCost
                priority = newCost + heuristics[neighbour[0]]
                open.put((priority, neighbour[0],))
                parents[neighbour[0]] = current[1]
    return False,