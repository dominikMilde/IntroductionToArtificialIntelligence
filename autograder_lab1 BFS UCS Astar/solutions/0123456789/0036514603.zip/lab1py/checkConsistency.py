def checkConsistency(heuristics, transitions):
    passed = True
    for t in transitions:
        for neighbour in transitions[t]:
            if heuristics[t] <= heuristics[neighbour[0]] + neighbour[1]:
                print("[CONDITION]: [OK] h("+t+") <= h(" + neighbour[0]+") + c:", round(heuristics[t],1) , "<=", round(heuristics[neighbour[0]],1), "+", round(neighbour[1],1))
            else:
                print("[CONDITION]: [ERR] h("+t+") <= h(" + neighbour[0]+") + c:", round(heuristics[t],1) , "<=", round(heuristics[neighbour[0]],1), "+", round(neighbour[1],1))
                passed = False
    if passed:
        print("[CONCLUSION]: Heuristic is consistent.")
    else:
        print("[CONCLUSION]: Heuristic is not consistent.")
    return
