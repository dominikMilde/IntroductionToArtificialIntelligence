from readInputs import readInputs
from readHeuristics import readHeuristics
from ucs import ucs
from bfs import bfs
from astar import astar
from checkOptimistic import checkOptimistic
from checkConsistency import checkConsistency

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--alg", type=str, help="search alg")
parser.add_argument("--ss", type=str, help="path to file with information about nodes")
parser.add_argument("--h", type=str, help="path to heuristics information")
parser.add_argument("--check-optimistic", help="heuristics optimistic check", action="store_true")
parser.add_argument("--check-consistent", help="heuristics consistency check", action="store_true")
args = parser.parse_args()


def printRets(retS):
    if retS[0]:
        print("[FOUND_SOLUTION]: yes")
        print("[STATES_VISITED]:", retS[1])
        print("[PATH_LENGTH]:", retS[2])
        print("[TOTAL_COST]:", retS[3])
        print("[PATH]: ", end="")
        for i in range(len(retS[4])-1):
            print(retS[4][i], "=> ", end="")
        print(retS[4][-1])
    else:
        print("[FOUND_SOLUTION]: no")


if args.alg:
    if args.alg == "bfs":
        start, end, trans = readInputs(args.ss)
        print("# BFS")
        rets = bfs(start, end, trans)
        printRets(rets)
    if args.alg == "ucs":
        start, end, trans = readInputs(args.ss)
        print("# UCS")
        rets = ucs(start, end, trans)
        printRets(rets)
    if args.alg == "astar":
        start, end, trans = readInputs(args.ss)
        heur = readHeuristics(args.h)
        print("# A-STAR", args.h)
        rets = astar(start, end, trans, heur)
        printRets(rets)
    exit(0)

if args.check_optimistic:
    print("# HEURISTIC-OPTIMISTIC", args.h)
    start, end, trans = readInputs(args.ss)
    heur = readHeuristics(args.h)
    checkOptimistic(heur, start, end, trans)
if args.check_consistent:
    print("# HEURISTIC-CONSISTENT", args.h)
    start, end, trans = readInputs(args.ss)
    heur = readHeuristics(args.h)
    checkConsistency(heur, trans)