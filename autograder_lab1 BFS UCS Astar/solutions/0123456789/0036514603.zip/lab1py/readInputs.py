def readInputs(path):

    f = open(path)

    startState = ""
    endStates = []
    transitions = {}
    while True:
        a = f.readline()
        if a.startswith('#'):
            continue
        else:
            startState = a[:-1]  # makni \n
            break

    while True:
        a = f.readline()
        if a.startswith('#'):
            continue
        else:
            endStates = a.split(' ')
            endStates[-1] = endStates[-1][:-1] #makni \n
            break

    while True:
        a = f.readline()
        if a == "":
            break
        else:
            stateSuccessors = a.split(':')
            if stateSuccessors[1] == "\n":
                transitions[stateSuccessors[0]] = []
                continue
            stateSuccessors[1] = stateSuccessors[1].strip()
            successors = stateSuccessors[1].split(' ')
            #print(susjedi)
            listForValue = []
            for s in successors:
                pair = s.split(',')
                #print(pair)
                #print(pair)
                pair[1] = float(pair[1])
                listForValue.append(pair)
            transitions[stateSuccessors[0]] = listForValue

    return startState, endStates, transitions

