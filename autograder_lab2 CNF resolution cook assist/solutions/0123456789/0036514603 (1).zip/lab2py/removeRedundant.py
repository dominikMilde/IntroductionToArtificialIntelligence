def removeRedundant(clauses):
    redundant = set()
    for clause in clauses:
        for secondClause in clauses:
            if clause.issubset(secondClause) and len(secondClause) > len(clause):
                redundant.add(secondClause)

    return clauses - redundant
