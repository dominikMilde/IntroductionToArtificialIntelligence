def removeTautology(clauses):
    tautology = set()
    for clause in clauses:
        for literal in clause:
            if literal.startswith('~'):
                if literal[1:] in clause:
                    tautology.add(clause)

    return clauses - tautology
