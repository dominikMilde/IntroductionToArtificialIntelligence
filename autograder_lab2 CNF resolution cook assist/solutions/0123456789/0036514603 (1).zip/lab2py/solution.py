from UtilConvert import convertToSet, convertNegated
from readResolution import readResolution
from readCooking import readCooking
from resolution import resolution
import sys

if len(sys.argv) < 3:
    print("Nedovoljno argumenata!")
    exit()


if sys.argv[1] == "resolution":
    clauses, goal, textGoal = readResolution(sys.argv[2])

    resolution(clauses, goal, textGoal)

if sys.argv[1] == "cooking":
    if len(sys.argv) < 4:
        print("Nedovoljno argumenata!")
        exit()
    clauses = readCooking(sys.argv[2])

    f = open(sys.argv[3])
    while True:
        a = f.readline()
        a = a.lower()
        if a == "":
            break
        if a.startswith('#'):
            continue
        else:
            a = a.strip()
            if a[-1] == "+":
                clauses.add(convertToSet(a[0:len(a)-2]))
            if a[-1] == "-":
                clauses.discard(convertToSet(a[0:len(a)-2]))
            if a[-1] == "?":
                print("User input: " + a)
                goal = convertNegated(a[0:len(a)-2])
                resolution(clauses, goal, a[0:len(a)-2])
