from printTrack import printTrack
from removeRedundant import removeRedundant
from removeTautology import removeTautology
from resolveSos import resolveSos


def resolution(clauses, goal, textGoal):
    setGoal = set()
    for i in goal:
        setGoal.add(frozenset({i}))  # just to meet required form for tautology and redundant functions

    clauses = removeTautology(clauses)
    clauses = removeRedundant(clauses)
    # print(clauses)

    sos = removeTautology(setGoal)
    sos = removeRedundant(sos)
    # print(sos)

    tracker = dict()
    for clause in clauses:
        tracker[clause] = None
    for clause in sos:
        tracker[clause] = None

    # actual algorithm
    while True:
        resolvents, tracker = resolveSos(sos, sos.union(clauses), tracker)
        # print("REZ:", resolvents)
        # time.sleep(1)
        if frozenset() in resolvents:
            printTrack(tracker)
            print("============================")
            print("[CONCLUSION]: " + textGoal + " is true")
            break
        clauses = clauses.union(sos)
        clauses = removeTautology(clauses)
        clauses = removeRedundant(clauses)

        sos = resolvents
        sos = removeTautology(sos)
        sos = removeRedundant(sos)

        if sos.issubset(clauses):
            print("[CONCLUSION]: " + textGoal + " is unknown")
            break
