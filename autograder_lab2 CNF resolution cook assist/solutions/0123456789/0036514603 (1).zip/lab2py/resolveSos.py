def resolveSos(sos, clauses, tracker):
    resolvents = set()
    for s in sos:
        for clause in clauses:
            r = resolvePair(s, clause)
            #print("resolved:", r)
            if r is not None:
                resolvents.add(r)
                tracker[r] = set({s, clause})
    return resolvents, tracker


def resolvePair(s, clause):
    #print("resolving:", s, clause)
    for literal in s:
        if literal.startswith("~") and literal[1:] in clause:
            return frozenset((s.difference(frozenset({literal}))).union(clause.difference(frozenset({literal[1:]}))))

        elif ("~" + literal) in clause:
            return frozenset((s.difference(frozenset({literal}))).union(clause.difference(frozenset({"~" + literal}))))

