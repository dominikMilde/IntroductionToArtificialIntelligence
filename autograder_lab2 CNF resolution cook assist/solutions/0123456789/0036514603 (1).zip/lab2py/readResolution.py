def readResolution(path):
    f = open(path)

    clauses = []
    clausesOut = set()
    last = ""

    while True:
        a = f.readline()
        a = a.lower()
        if a == "":
            break
        if a.startswith('#'):
            continue
        else:
            last = a
            clauses.append(a)

    clauses = clauses[0:len(clauses)-1]
    for c in clauses:
        splitted = c.split(' v ')
        splitted = [s.strip() for s in splitted]
        inner = frozenset(splitted)
        clausesOut.add(inner)

    goal = set()
    goalSplitted = last.split('v')
    goalSplitted = [s.strip() for s in goalSplitted]
    for g in goalSplitted:
        if g.startswith('~'):
            goal.add(g[1::])
        else:
            goal.add("~" + g)
    f.close()
    return clausesOut, goal, last.strip()
    # return clauses and negated goal
