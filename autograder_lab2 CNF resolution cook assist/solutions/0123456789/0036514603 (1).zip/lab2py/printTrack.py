def printTrack(tracker):
    print("Pocetne premise:")
    for k in tracker:
        if tracker[k] is None:
            print(printClause(k))
    print("============================")
    root = frozenset()
    postorder(root, tracker)


def postorder(root, tracker):
    if tracker[root]:
        for clause in tracker[root]:
            postorder(clause, tracker)
        print(printClause(root), "je dobiven rezolucijom: ", printClauses(tracker[root]))

def printClause(clause):
    if clause == frozenset():
        return "NIL"
    else:
        string = ""
        for c in clause:
            string += c + " v "
        return string[0:len(string)-3]

def printClauses(clauses):
    string = ""
    for c in clauses:
        string += "("+ printClause(c) + ") i "
    return string[0:len(string)-3]
