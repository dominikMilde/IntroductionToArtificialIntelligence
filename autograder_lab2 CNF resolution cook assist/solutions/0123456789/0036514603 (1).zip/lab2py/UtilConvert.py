def convertToSet(string):
    splitted = string.split(' v ')
    splitted = [s.strip() for s in splitted]
    inner = frozenset(splitted)
    return inner


def convertNegated(string):
    goal = set()
    goalSplitted = string.split('v')
    goalSplitted = [s.strip() for s in goalSplitted]
    for g in goalSplitted:
        if g.startswith('~'):
            goal.add(g[1::])
        else:
            goal.add("~" + g)
    return goal
