def readCooking(path):
    f = open(path)

    clauses = []
    clausesOut = set()

    while True:
        a = f.readline()
        a = a.lower()
        if a == "":
            break
        if a.startswith('#'):
            continue
        else:
            clauses.append(a)

    for c in clauses:
        splitted = c.split(' v ')
        splitted = [s.strip() for s in splitted]
        inner = frozenset(splitted)
        clausesOut.add(inner)

    return clausesOut
