import sys
import math
import csv

def loadCvs(path):
    csv_data = csv.reader(open(path, newline='\n'))

    rows = []
    for d in csv_data:
        rows.append(d)

    headers = rows[0]
    ind2name, name2ind = nameToIndex(headers)

    data = {
        'header': headers,
        'rows': rows[1:],
        'name_to_idx': name2ind,
        'idx_to_name': ind2name
    }
    return data


def nameToIndex(headers):
    name2ind = {}
    ind2name = {}
    for i in range(len(headers)):
        name2ind[headers[i]] = i
        ind2name[i] = headers[i]
    # print(ind2name)
    # print(ind2name.keys())
    return ind2name, name2ind


def uniqueValues(data):
    ind2name = data['idx_to_name']
    mapValues = {}
    idxs = ind2name.keys()
    # print(idxs)

    for idx in iter(idxs):
        mapValues[ind2name[idx]] = set()

    for row in data['rows']:
        for idx in ind2name.keys():
            value = row[idx]
            attribute = ind2name[idx]
            if value not in mapValues.keys():
                mapValues[attribute].add(value)
    return mapValues

def getLabels(data, wanted):
    labels = {}
    cols = data['name_to_idx'][wanted]
    rows = data['rows']

    for rw in rows:
        val = rw[cols]
        if val not in labels:
            labels[val] = 1
        else:
            labels[val] = labels[val] + 1

    return labels


def getEntropy(n, labels):
    sum = 0
    for label in labels.keys():
        sum += - labels[label] * 1.0 / n * math.log(labels[label] * 1.0 / n, 2)
    return sum


def makePartitions(data, part):
    parts = {}
    data_rows = data['rows']
    # print(data_rows)
    index = data['name_to_idx'][part]
    # print(index)
    for row in data_rows:
        value = row[index]
        if value not in parts.keys():
            # print(value)
            parts[value] = {
                'name_to_idx': data['name_to_idx'],
                'idx_to_name': data['idx_to_name'],
                'rows': list()
            }
        parts[value]['rows'].append(row)
    # print(len(parts))
    return parts


def getAverageEntropyFor(data, current, wanted):
    # find uniq values of splitting att
    data_rows = data['rows']
    n = len(data_rows)
    parts = makePartitions(data, current)

    average = 0

    for k in parts.keys():
        dataPart = parts[k]
        labels = getLabels(dataPart, wanted)
        numOfParts = len(dataPart['rows'])

        entropy = getEntropy(numOfParts, labels)
        average += numOfParts / n * entropy

    return average, parts

def getMostLikely(labels):
    # print(labels)
    mcl = min(labels, key=lambda k: (-labels[k], k))
    # print(mcl)
    return mcl

def traverse(node, memory, rules, counter):
    if 'attribute' in node:
        memory.append(str(counter) + ":" + node['attribute'] + '=')
        for child in node['nodes']:
            memory.append(child + " ")
            traverse(node['nodes'][child], memory, rules, counter+1)
            memory.pop()
        memory.pop()
    elif 'label' in node:
        memory.append(node['label'])
        rules.add(''.join(memory))
        memory.pop()


def printTree(root):
    print("[BRANCHES]: ")
    memory = []
    rules = set()

    traverse(root, memory, rules, 1)
    for r in rules:
        print(r)


class ID3:
    def __init__(self, depth=100000):
        self.tree = None
        self.depth = depth
        self.data = None
        self.goal = None
        self.attr = None
        self.unique = None

    def fit(self, training_data):
        self.data = training_data
        self.goal = self.data["header"][-1]
        self.attr = set(self.data['header'])
        self.attr.remove(self.goal)
        self.unique = uniqueValues(self.data)

        self.tree = self.id3fun(self.data, self.unique, self.attr, self.goal, 0)

        printTree(self.tree)
        # print(self.tree)

    def predict(self, testing_data):
        print("[PREDICTIONS]: ", end="")
        predictions = []

        for atrs in testing_data["rows"]:
            dictionary = {}
            for i in range(len(atrs)):
                dictionary[testing_data["idx_to_name"][i]] = atrs[i]
            predictions.append(self.onePrediction(dictionary, self.tree))

        for prediction in predictions:
            print(prediction, end=" ")
        print()

        categories = set(predictions)
        correct = 0

        for i in range(len(testing_data["rows"])):
            categories.add(testing_data["rows"][i][-1])
            if predictions[i] == testing_data["rows"][i][-1]:
                correct += 1
        categoryList = list(categories)
        categoryList.sort()

        accuracy = correct / len(testing_data["rows"])
        print("[ACCURACY]: ", end="")
        print("%.5f" % accuracy)

        print("[CONFUSION_MATRIX]:")
        for real in categoryList:
            for pred in categoryList:
                counter = 0
                for i in range(len(predictions)):
                    if testing_data["rows"][i][-1] == real and predictions[i] == pred:
                        counter += 1
                print(counter, end=" ")
            print()

    def onePrediction(self, query, tree):
        if 'label' in tree:
            # print("vracam" + tree['label'])
            return tree['label']
        for atr in query.keys():
            if atr in tree['attribute']:
                trimmedTree = tree['nodes'][query[atr]]
                return self.onePrediction(query, trimmedTree)

    def id3fun(self, data, uniqVals, atributesToDo, wanted, curr_depth):
        treeNode = {}
        #print(curr_depth)

        labels = getLabels(data, wanted)
        #print(labels)


        if int(curr_depth) == int(self.depth):
            treeNode['label'] = getMostLikely(labels)
            return treeNode

        if len(labels.keys()) == 1:
            labels1 = list(labels.keys())
            #print(labels1)
            treeNode['label'] = next(iter(labels.keys()))
            return treeNode

        if len(atributesToDo) == 0:
            treeNode['label'] = getMostLikely(labels)
            return treeNode

        entropy = getEntropy(len(data['rows']), labels)

        bestAtr = None
        maxIG = None
        bestPart = None
        atributesToDo = list(atributesToDo)
        atributesToDo.sort()

        for atr in atributesToDo:
            #print(remaining_att)
            avg_ent, partitions = getAverageEntropyFor(data, atr, wanted)
            info_gain = entropy - avg_ent
            if maxIG is None or info_gain > maxIG:
                # print(tusam)
                maxIG = info_gain
                bestAtr = atr
                bestPart = partitions

        if maxIG is None:
            treeNode['label'] = getMostLikely(labels)
            return treeNode

        treeNode['nodes'] = {}

        treeNode['attribute'] = bestAtr
        # print("a")

        remaining_atts_for_subtrees = set(atributesToDo)
        remaining_atts_for_subtrees.discard(bestAtr)

        uniqs = uniqVals[bestAtr]

        for value in uniqs:
            # print("value", len(uniqs))
            if value not in bestPart.keys():
                treeNode['nodes'][value] = {'label': getMostLikely(labels)}
                continue
            partition = bestPart[value]
            treeNode['nodes'][value] = self.id3fun(partition, uniqVals, remaining_atts_for_subtrees, wanted, curr_depth+1)

        return treeNode


learningData = loadCvs(sys.argv[1])
testData = loadCvs(sys.argv[2])

if len(sys.argv) == 4:
    model = ID3(sys.argv[3])
else:
    model = ID3()

model.fit(learningData)
model.predict(testData)





